//
//
//
// file: main_p5.cpp
// last modified:
// copyright:
// version:
//
// email:
// web:
//



#include <iostream>
#include <cstdlib>
//#include <iomanip>
//#include <iterator>


#include "human.h"
#include "elf.h"
#include "cyberdemon.h"
#include "balrog.h"

using namespace std;



int main(/* int argc, char *argv[] */ )
{

    srand(1500);

    Human h0(10,10);
    Elf e0(10,10);
    Cyberdemon c0(10,10);
    Balrog b0(10,10);

    Creature * Entity[] = { &h0, &e0, &c0, &b0};

    for(int i=0;;i++)
    {
        cout<<"Turn "<<i<<":"<<endl;
        cout<<"\t";
        Entity[0]->getDamage();
        cout<<"\t";
        Entity[1]->getDamage();
        cout<<"\t";
        Entity[2]->getDamage();
        cout<<"\t";
        Entity[3]->getDamage();
        cout<<"\t";
        cout<<endl;
//        _sleep(1000);
        system("pause");
    }

/*
    for(int i=0;;i++)
    {
        cout<<"Turn "<<i<<":"<<endl;
        cout<<"\t";
        h0.getDamage();
        cout<<"\t";
        e0.getDamage();
        cout<<"\t";
        c0.getDamage();
        cout<<"\t";
        b0.getDamage();
        cout<<"\t";
        cout<<endl;
//        _sleep(1000);
        system("pause");
    }
*/

    return 0;
}
